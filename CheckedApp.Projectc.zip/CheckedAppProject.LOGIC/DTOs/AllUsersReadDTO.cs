﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckedAppProject.LOGIC.DTOs
{
    public class AllUsersReadDTO
    {
        public List<string>  UserNameList { get; set; }
    }
}
