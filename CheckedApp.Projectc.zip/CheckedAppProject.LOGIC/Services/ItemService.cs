﻿
namespace CheckedAppProject.LOGIC.Services
{
    public class ItemService : IItemService
    {
        public void EditName(string itemName) { }
        public void DeleteItem(string itemName, int itemListId) { }
        public void ToggleItemToBuy(string itemName) { }
        public void ToggleItemToPack(string itemName) { }

    }
}