﻿
namespace CheckedAppProject.DATA
{
    public enum ItemState
    {
        toBuy,
        toPack,
        toBuyAndPack
    }
}
