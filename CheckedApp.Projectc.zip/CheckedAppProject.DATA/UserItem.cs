﻿
namespace CheckedAppProject.DATA
{
    public class UserItem
    {
        public Item ItemType { get; set; }
        public int UserItemId { get; set; }
        public enum ItemState { }
    }
}
