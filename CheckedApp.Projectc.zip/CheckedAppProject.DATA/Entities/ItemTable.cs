﻿
namespace CheckedAppProject.DATA.Entities
{
    public class ItemTable
    {
        public int ItemTableId { get; set; }
        public string ItemName { get; set; }
        public string? ItemCompany { get; set; }
        public List<ItemListTable> ItemListTables { get; set; }

    }
}
