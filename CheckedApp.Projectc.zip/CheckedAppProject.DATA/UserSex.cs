﻿
namespace CheckedAppProject.DATA
{
    public enum UserSex
    {
        Male,
        Female,
        None
    }
}
