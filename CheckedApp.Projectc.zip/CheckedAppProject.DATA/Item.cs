﻿
namespace CheckedAppProject.DATA
{
    public class Item
    {
        public string ItemName { get; set; }
        public string CompanyName { get; set; }
        public int ItemID {  get; set; }
    }
}
