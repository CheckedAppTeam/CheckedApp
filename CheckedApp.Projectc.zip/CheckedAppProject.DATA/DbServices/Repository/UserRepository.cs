﻿
using System.Diagnostics.Contracts;

namespace CheckedAppProject.DATA.DbServices.Repository
{
    public class UserRepository
    {
        public List<User> UserList { get; set; }

    }
}
