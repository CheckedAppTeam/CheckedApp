﻿namespace CheckedAppProject.DATA.DbServices.Repository
{
    public class ItemListRepository
    {
        public List<ItemList> ItemLists { get; set; }
    }
}
