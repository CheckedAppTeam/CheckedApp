﻿namespace CheckedAppProject.DATA.DbServices.Repository
{
    public class ItemRepository
    {
        public List<Item> Items { get; set; }

    }
}
